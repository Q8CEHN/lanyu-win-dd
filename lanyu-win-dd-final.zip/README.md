# LANYU Windows Server 2022 Universal Reinstall

Installs:

- Windows Server 2022 Datacenter
- Simplified Chinese (`zh-cn`)
- Desktop Experience (non-Core)
- RDP port `3389`
- Administrator account
- ISO automatically selected by `bin456789/reinstall`

> Warning: the entire VPS system disk will be erased after reboot.

## Usage

Run as `root`:

```bash
curl -fL https://raw.githubusercontent.com/Q8CEHN/lanyu-win-dd/main/lanyu_win2022.sh -o /root/dd-win2022.sh && chmod +x /root/dd-win2022.sh
```

Then:

```bash
sh /root/dd-win2022.sh
```

The script will:

1. Check that the VPS is `x86_64/amd64`.
2. Refuse common unsupported container environments such as OpenVZ/LXC.
3. Install basic tools on common Linux distributions.
4. Check RAM and disk size.
5. Download the latest upstream `bin456789/reinstall`.
6. Check access to the automatic Windows ISO index.
7. Prepare Windows Server 2022 Datacenter installation.

When prompted, type:

```text
DD
```

Set the Windows Administrator password when the upstream installer asks for it.

If preparation completes without errors, run:

```bash
reboot
```

Then wait for the installer to finish and reboot into Windows.

## RDP

```text
User: Administrator
Port: 3389
Password: the password you set during preparation
```

## Notes

- This wrapper does not use the previous `img.lanyu.org` WebDAV ISO.
- It asks the upstream reinstall project to automatically locate a Windows Server 2022 `zh-cn` ISO.
- The requested image is `Windows Server 2022 ServerDatacenter`, not `ServerDatacenterCore`.
- Windows activation/licensing is separate from installation.
